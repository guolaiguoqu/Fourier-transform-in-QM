questions:
1. why H and p have to have different signs? (consistence with special relativity?)
2. issues with the eigenvalue/eigenvector approach. For instance, the eigenvalue of Hamiltonian is not always energy.
3. why the quotient of E/w and p/k have to be the same?